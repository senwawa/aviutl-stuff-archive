--[[UTF8

	外部バッファ
		画像データの一時保存と読み込み機能を提供する。
		この機能では、aviutl 標準の仮想バッファを使用していないため、

			画像を一時保存

			→仮想バッファで別の画像を編集、描画

			→一時保存した画像を読み込み

		が可能となる。

		なお、保存できる画像データのサイズ制限、枚数制限は特に設けていない。

	依存モジュール：
		extbuffer_core.dll

	パッケージ：
		extbuffer
		extbuffer.core

	パッケージ関数：
		extbuffer.freeid
		extbuffer.write
		extbuffer.write2
		extbuffer.size
		extbuffer.read
		extbuffer.read2
		extbuffer.clear
		extbuffer.swap

	使用方法：
		--script フォルダに、extbuffer.lua と extbuffer_core.dll が存在することが前提
		require("extbuffer")

	関数仕様：
		id = extbuffer.freeid()
			外部バッファの空きIDを取得する

			ID は任意の文字列、または任意の整数値を受け入れる。

		extbuffer.write(id)
			外部バッファの id 面に obj の持つ画像イメージを書きこむ

		extbuffer.write2(id, userdata, w, h)
			外部バッファの id 面に userdata を書きこむ

		extbuffer.clear(id)
			外部バッファの id 面をクリアする

			保存したデータはクリアしないといつまでもメモリに残ることに注意

		w, h = extbuffer.size(id)
			外部バッファの id 面に保存されている画像イメージのサイズ
			画像が保存されていなければ、0, 0 が返る

		extbuffer.read(id)
			外部バッファの id 面から obj に画像イメージを読みこむ
			obj のサイズは、id 面の画像データサイズと一致するようにリサイズされる

		userdata, w, h = extbuffer.read2(id)
			外部バッファの id 面から画像イメージを読みこむ
			この関数が返す userdata は obj.putpixeldata で使用できない
			他のDLLと画像イメージをやりとりするための機能

		extbuffer.swap(userdata, w, h)
			obj の画像イメージと userdata の画像イメージを交換する

	性能：
		画像サイズによる。
]]
extbuffer = extbuffer or {}

require("extbuffer_core")

extbuffer.freeid = function()
	return extbuffer.core.freeid()
end

extbuffer.write = function(id)
	id = id or ""
	if(extbuffer.core.type(id) == "number")then
		id = math.floor(id)
	end

	local userdata, w, h = obj.getpixeldata()
	extbuffer.core.write(id, userdata, w, h)
end

extbuffer.write2 = function(id, userdata, w, h)
	if(extbuffer.core.type(userdata) ~= "userdata")then
		return
	end

	id = id or ""
	if(extbuffer.core.type(id) == "number")then
		id = math.floor(id)
	end

	extbuffer.core.write(id, userdata, w, h)
end

extbuffer.size = function(id)
	id = id or ""
	if(extbuffer.core.type(id) == "number")then
		id = math.floor(id)
	end

	return extbuffer.core.size(id)
end

extbuffer.read = function(id)
	id = id or ""
	if(extbuffer.core.type(id) == "number")then
		id = math.floor(id)
	end

	local w1, h1 = extbuffer.core.size(id)
	local w2, h2 = obj.getpixel()
	
	--resize
	if(h1>h2 or w1>w2)then
		if(h1==obj.screen_h and w1==obj.screen_w)then
			obj.load("framebuffer")
		else
			obj.load("figure","四角形",0,math.max(w1,h1))
			w2, h2 = obj.getpixel()
			local ue = math.floor((h2 - h1) / 2)
			local shita = (h2 - h1) - ue
			local hidari = math.floor((w2 - w1) / 2)
			local migi = (w2 - w1) - hidari
			obj.effect("クリッピング","上",ue,"下",shita,"左",hidari,"右",migi)
		end
	elseif(h1<h2 or w1<w2)then
		local ue = math.floor((h2 - h1) / 2)
		local shita = (h2 - h1) - ue
		local hidari = math.floor((w2 - w1) / 2)
		local migi = (w2 - w1) - hidari
		obj.effect("クリッピング","上",ue,"下",shita,"左",hidari,"右",migi)
	end

	local userdata = obj.getpixeldata()
	extbuffer.core.read(id, userdata)
	obj.putpixeldata(userdata)
end

extbuffer.read2 = function(id)
	id = id or ""
	if(extbuffer.core.type(id) == "number")then
		id = math.floor(id)
	end

	--この関数で読みだしたデータは obj にプットしても無視される
	--return userdata, w, h
	return extbuffer.core.read2(id)
end

extbuffer.clear = function(id)
	id = id or ""
	if(extbuffer.core.type(id) == "number")then
		id = math.floor(id)
	end

	extbuffer.core.clear(id)
end

extbuffer.swap = function(userdata, w, h)
	if(extbuffer.core.type(userdata) ~= "userdata")then
		return
	end

	local id1 = extbuffer.freeid()
	extbuffer.write(id1)
	local id2 = extbuffer.freeid()
	extbuffer.write2(id2, userdata, w, h)

	extbuffer.read(id2)
	userdata, w, h = extbuffer.read2(id1)

	extbuffer.clear(id1)
	extbuffer.clear(id2)
end
